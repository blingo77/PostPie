#display.py
# Copyright (C) 2024 the PostPie developers
# (See DEVELOPERS FILE)